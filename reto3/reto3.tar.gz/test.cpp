#include <iostream>
#include "myStack.h"

using namespace std;

int main(){
  cout << "hola" << endl;
}
