var searchData=
[
  ['unir',['unir',['../classFechaHistorica.html#a7ca1983001d4a8f96bf850cead5c6657',1,'FechaHistorica']]]
];
