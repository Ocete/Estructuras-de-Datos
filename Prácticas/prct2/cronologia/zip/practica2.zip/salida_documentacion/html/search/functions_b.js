var searchData=
[
  ['vector_5fdinamico',['vector_dinamico',['../classvector__dinamico.html#a7e63184c175452768db71068dad54dce',1,'vector_dinamico']]]
];
