var searchData=
[
  ['add',['add',['../classvector__dinamico.html#aa5a16f253878cadc3bf7d0075a442bbc',1,'vector_dinamico']]],
  ['addevento',['addEvento',['../classFechaHistorica.html#aacf5b184c161f2445e84ccf5f3d6d15a',1,'FechaHistorica']]],
  ['addfechahistorica',['addFechaHistorica',['../classCronologia.html#a03f7166f3fd5f454556a768b02f70513',1,'Cronologia']]],
  ['addordenado',['addOrdenado',['../classvector__dinamico.html#ae3f18c71d0919cd6fd5d7f9156eb2012',1,'vector_dinamico']]]
];
