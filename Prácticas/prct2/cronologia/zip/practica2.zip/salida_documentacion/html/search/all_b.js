var searchData=
[
  ['vector_5fdinamico',['vector_dinamico',['../classvector__dinamico.html',1,'vector_dinamico&lt; T &gt;'],['../classvector__dinamico.html#a7e63184c175452768db71068dad54dce',1,'vector_dinamico::vector_dinamico()']]],
  ['vector_5fdinamico_2eh',['vector_dinamico.h',['../vector__dinamico_8h.html',1,'']]],
  ['vector_5fdinamico_3c_20fechahistorica_20_2a_20_3e',['vector_dinamico&lt; FechaHistorica * &gt;',['../classvector__dinamico.html',1,'']]],
  ['vector_5fdinamico_3c_20string_20_3e',['vector_dinamico&lt; string &gt;',['../classvector__dinamico.html',1,'']]]
];
