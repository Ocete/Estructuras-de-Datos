var searchData=
[
  ['operator_3e_3e',['operator&gt;&gt;',['../classCronologia.html#abd1b503834430c84fc252510c8ba8af6',1,'Cronologia::operator&gt;&gt;()'],['../classFechaHistorica.html#a6a880c96956c05dfeb15f991f9f95992',1,'FechaHistorica::operator&gt;&gt;()']]]
];
