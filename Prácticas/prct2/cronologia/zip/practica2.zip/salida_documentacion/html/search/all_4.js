var searchData=
[
  ['getcap',['getCap',['../classvector__dinamico.html#ac3c8e44621070895a060a079f0332815',1,'vector_dinamico']]],
  ['getelems',['getElems',['../classvector__dinamico.html#a27a65ef663698152f804cd9aa9507721',1,'vector_dinamico']]],
  ['getevento',['getEvento',['../classFechaHistorica.html#a2bbc4ac817bf3023c328dfccf3f23c4f',1,'FechaHistorica']]],
  ['getfecha',['getFecha',['../classFechaHistorica.html#a4ab24b45a0a55f175d651cd5600e685e',1,'FechaHistorica']]],
  ['getfechahistorica',['getFechaHistorica',['../classCronologia.html#a1f8da1bb1cb162961211f9234c4ca88d',1,'Cronologia']]],
  ['getnumeventos',['getNumEventos',['../classFechaHistorica.html#afb95802d94856b35b6e143ab97f27330',1,'FechaHistorica']]],
  ['getnumfechashistoricas',['getNumFechasHistoricas',['../classCronologia.html#acd10707ea9d2d308af06a291d3f06522',1,'Cronologia']]]
];
