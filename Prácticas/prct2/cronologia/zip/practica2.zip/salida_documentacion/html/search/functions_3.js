var searchData=
[
  ['fechahistorica',['FechaHistorica',['../classFechaHistorica.html#a8b8247718415883493f661b9e6d98acc',1,'FechaHistorica::FechaHistorica(int anio)'],['../classFechaHistorica.html#a8f246156cdac561077ae7b13ea6580c0',1,'FechaHistorica::FechaHistorica(const FechaHistorica &amp;fh)']]]
];
