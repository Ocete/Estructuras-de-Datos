var searchData=
[
  ['subcronologia',['subcronologia',['../classCronologia.html#a963766a08f3714b15a9caa2fba20bd30',1,'Cronologia::subcronologia(int anioDesde, int anioHasta) const '],['../classCronologia.html#a3ed74df85eda1db63f8228c26de8227e',1,'Cronologia::subcronologia(string clave) const ']]]
];
