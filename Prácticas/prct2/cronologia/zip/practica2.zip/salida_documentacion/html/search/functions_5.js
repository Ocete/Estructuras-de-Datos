var searchData=
[
  ['interseccron',['intersecCron',['../classCronologia.html#a3d7645f2ff66fc9f7e5385c4568cce09',1,'Cronologia']]]
];
