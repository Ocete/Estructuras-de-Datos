var searchData=
[
  ['vector_5fdinamico',['vector_dinamico',['../classvector__dinamico.html',1,'']]],
  ['vector_5fdinamico_3c_20fechahistorica_20_2a_20_3e',['vector_dinamico&lt; FechaHistorica * &gt;',['../classvector__dinamico.html',1,'']]],
  ['vector_5fdinamico_3c_20string_20_3e',['vector_dinamico&lt; string &gt;',['../classvector__dinamico.html',1,'']]]
];
