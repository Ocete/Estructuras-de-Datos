var searchData=
[
  ['mergecron',['mergeCron',['../classCronologia.html#a84b2af465befa1375cd516b4945f6947',1,'Cronologia']]]
];
